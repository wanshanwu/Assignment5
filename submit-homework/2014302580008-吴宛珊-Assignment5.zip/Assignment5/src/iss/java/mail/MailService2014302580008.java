package iss.java.mail;
import javax.mail.*;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;

public class MailService2014302580008 implements IMailService {
	private Session session = null;
	private Message smessage;
    private Date sentDate = null;

	@Override
    public void connect() throws MessagingException {
		Properties properties = System.getProperties();
		
		properties.put("mail.smtp.auth", true);
	       properties.put("mail.store.protocol", "pop3");
	       properties.put("mail.smtp.host", "smtp.163.com");
	       properties.put("mail.pop3.host", "pop3.163.com"); 


        
        Authenticator authenticator=new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("15827425155@163.com", "aqegzagvsdyylnye");
                
            }
        };
        session = Session.getInstance(properties, authenticator);
        		}
	@Override
    public void send(String recipient, String subject, Object content) throws MessagingException {
		smessage = new MimeMessage(session);
        smessage.setFrom(new InternetAddress("15827425155@163.com"));
        smessage.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
        smessage.setSubject(subject);
        smessage.setContent(content, "text/html;charset=utf-8");
        sentDate = new Date();
        Transport.send(smessage);

		
		
	}
	 @Override
	    public boolean listen() throws MessagingException {
		 Store store = session.getStore();
	        store.connect();
	        Folder myFolder = store.getFolder("Inbox");
	        myFolder.open(Folder.READ_ONLY);
	        Message[] messages = myFolder.getMessages();
	        for(Message message : messages){
	            String date = message.getHeader("date")[0];
	            Date receiveDate = new Date(date);

	            if(sentDate.before(receiveDate)){
	                myFolder.close(false);
	                return true;
	            }
	        }
	        myFolder.close(false);
	        return false;

			
		 
	 }
	 @Override
	    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		 Store store = session.getStore();
	     store.connect();
	     Folder folder = store.getFolder("INBOX");
	     folder.open(Folder.READ_ONLY);
	     
	     Message messages[] = folder.getMessages();
	     
	     for(int i=0;i<=messages.length;i++){
	    	 String date = messages[i].getHeader("date")[0];
	            Date receiveDate = new Date(date);
	            if (sentDate.after(receiveDate)){
	                continue;
	            }
	            if(subject.equals(messages[i].getSubject())){
	                String content = messages[i].getContent().toString();
	                folder.close(false);
	                return content;
	            }
	            i+=1;

	    	 
	     }
	     folder.close(false);
		 store.close();
		 return null;
	 }

}
